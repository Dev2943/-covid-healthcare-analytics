"""
app.py  —  COVID-19 Healthcare Analytics Dashboard
---------------------------------------------------
Full-stack Plotly Dash application covering:
  Tab 1 — Geospatial Spread         (choropleth + time slider)
  Tab 2 — Resource Utilization      (ICU / hosp trends + capacity stress)
  Tab 3 — ML Forecasting            (Prophet 30-day case forecast + surge alerts)

Run:
    pip install -r requirements.txt
    python dashboard/app.py
Then open http://127.0.0.1:8050 in your browser.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import dash
from dash import dcc, html, Input, Output, State, callback
import dash_bootstrap_components as dbc

from src.data_loader import load_and_filter
from src.preprocessing import (
    prepare_geospatial,
    prepare_resource_utilization,
    prepare_forecasting,
)
from src.forecasting import run_forecast_pipeline

# ── Colour palette ─────────────────────────────────────────────────────────
BRAND_BLUE    = "#1a73e8"
BRAND_RED     = "#d93025"
BRAND_ORANGE  = "#f4a261"
BRAND_GREEN   = "#2a9d8f"
BRAND_PURPLE  = "#6a4c93"
BG_DARK       = "#0f1117"
CARD_BG       = "#1c1f2e"
TEXT_LIGHT    = "#e8eaf6"
GRID_COLOR    = "#2a2d3e"

CHART_LAYOUT = dict(
    paper_bgcolor=CARD_BG,
    plot_bgcolor=CARD_BG,
    font=dict(color=TEXT_LIGHT, family="Inter, sans-serif"),
    margin=dict(l=40, r=20, t=40, b=40),
    xaxis=dict(gridcolor=GRID_COLOR, showgrid=True),
    yaxis=dict(gridcolor=GRID_COLOR, showgrid=True),
    legend=dict(bgcolor="rgba(0,0,0,0)"),
)

DEFAULT_COUNTRIES = ["United States", "United Kingdom", "Germany",
                     "India", "Brazil", "France"]

# ── Data loading (cached at module level) ───────────────────────────────────
print("Loading data …")
raw_df = load_and_filter()
all_countries = sorted(raw_df["location"].dropna().unique().tolist())
date_min = raw_df["date"].min().strftime("%Y-%m-%d")
date_max = raw_df["date"].max().strftime("%Y-%m-%d")
print(f"Data loaded: {len(raw_df):,} rows | {raw_df['location'].nunique()} countries")

# ── App initialisation ──────────────────────────────────────────────────────
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.CYBORG, dbc.icons.FONT_AWESOME],
    title="COVID-19 Healthcare Analytics",
    suppress_callback_exceptions=True,
)
server = app.server   # for deployment (Gunicorn / Render)

# ── Reusable components ─────────────────────────────────────────────────────

def stat_card(title: str, value: str, icon: str, color: str) -> dbc.Card:
    return dbc.Card(
        dbc.CardBody([
            html.Div([
                html.I(className=f"fa {icon} fa-2x", style={"color": color}),
                html.Div([
                    html.P(title, className="text-muted mb-0", style={"fontSize": "0.8rem"}),
                    html.H5(value, style={"color": color, "fontWeight": "700"}),
                ], className="ms-3"),
            ], className="d-flex align-items-center"),
        ]),
        style={"backgroundColor": CARD_BG, "border": f"1px solid {color}33"},
    )


# ── Layout ──────────────────────────────────────────────────────────────────

app.layout = dbc.Container([

    # ── Header
    dbc.Row([
        dbc.Col([
            html.H2("🦠 COVID-19 Healthcare Analytics",
                    style={"color": TEXT_LIGHT, "fontWeight": "800"}),
            html.P(
                f"Data: Our World in Data  ·  Updated through {date_max}  ·  "
                "Built for Healthcare Business Analytics Portfolio",
                className="text-muted", style={"fontSize": "0.85rem"},
            ),
        ])
    ], className="mt-3 mb-2"),

    # ── KPI strip (global totals)
    dbc.Row(id="kpi-row", className="mb-3"),

    # ── Main tabs
    dbc.Tabs([

        # ── TAB 1: Geospatial ──────────────────────────────────────────────
        dbc.Tab(label="🌍 Geospatial Spread", tab_id="tab-geo", children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Metric", className="text-muted mt-3"),
                    dcc.Dropdown(
                        id="geo-metric",
                        options=[
                            {"label": "Total Cases",           "value": "total_cases"},
                            {"label": "Total Deaths",          "value": "total_deaths"},
                            {"label": "Case Fatality Rate (%)", "value": "case_fatality_rate"},
                            {"label": "ICU Patients per Million", "value": "icu_per_million"},
                            {"label": "Hosp. Patients per Million", "value": "hosp_per_million"},
                        ],
                        value="total_cases",
                        clearable=False,
                        style={"backgroundColor": CARD_BG, "color": "#000"},
                    ),
                ], width=4),
                dbc.Col([
                    html.Label("As of Date", className="text-muted mt-3"),
                    dcc.DatePickerSingle(
                        id="geo-date",
                        min_date_allowed=date_min,
                        max_date_allowed=date_max,
                        date=date_max,
                        display_format="YYYY-MM-DD",
                    ),
                ], width=4),
            ]),
            dcc.Graph(id="choropleth-map", style={"height": "520px"}),

            dbc.Row([
                dbc.Col(dcc.Graph(id="top-countries-bar", style={"height": "350px"})),
                dbc.Col(dcc.Graph(id="cfr-scatter", style={"height": "350px"})),
            ]),
        ]),

        # ── TAB 2: Resource Utilization ────────────────────────────────────
        dbc.Tab(label="🏥 Resource Utilization", tab_id="tab-res", children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Select Countries", className="text-muted mt-3"),
                    dcc.Dropdown(
                        id="res-countries",
                        options=[{"label": c, "value": c} for c in all_countries],
                        value=["United States", "United Kingdom", "Germany"],
                        multi=True,
                        style={"backgroundColor": CARD_BG, "color": "#000"},
                    ),
                ], width=6),
                dbc.Col([
                    html.Label("Date Range", className="text-muted mt-3"),
                    dcc.DatePickerRange(
                        id="res-date-range",
                        min_date_allowed=date_min,
                        max_date_allowed=date_max,
                        start_date="2020-03-01",
                        end_date=date_max,
                        display_format="YYYY-MM-DD",
                    ),
                ], width=6),
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id="icu-trend",  style={"height": "350px"})),
                dbc.Col(dcc.Graph(id="hosp-trend", style={"height": "350px"})),
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id="bed-occupancy", style={"height": "350px"})),
                dbc.Col(dcc.Graph(id="resource-heatmap", style={"height": "350px"})),
            ]),
        ]),

        # ── TAB 3: Forecasting ─────────────────────────────────────────────
        dbc.Tab(label="📈 ML Forecast", tab_id="tab-fc", children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Country", className="text-muted mt-3"),
                    dcc.Dropdown(
                        id="fc-country",
                        options=[{"label": c, "value": c} for c in all_countries],
                        value="United States",
                        clearable=False,
                        style={"backgroundColor": CARD_BG, "color": "#000"},
                    ),
                ], width=4),
                dbc.Col([
                    html.Label("Target Variable", className="text-muted mt-3"),
                    dcc.Dropdown(
                        id="fc-target",
                        options=[
                            {"label": "Daily New Cases (smoothed)", "value": "new_cases_smoothed"},
                            {"label": "Daily New Deaths (smoothed)", "value": "new_deaths_smoothed"},
                            {"label": "ICU Patients", "value": "icu_patients"},
                            {"label": "Hospitalised Patients", "value": "hosp_patients"},
                        ],
                        value="new_cases_smoothed",
                        clearable=False,
                        style={"backgroundColor": CARD_BG, "color": "#000"},
                    ),
                ], width=4),
                dbc.Col([
                    html.Label("Forecast Horizon (days)", className="text-muted mt-3"),
                    dcc.Slider(id="fc-horizon", min=7, max=90, step=7, value=30,
                               marks={7: "7d", 30: "30d", 60: "60d", 90: "90d"}),
                ], width=4),
            ], className="mb-2"),

            dbc.Row([
                dbc.Col(
                    dbc.Button("▶ Run Forecast", id="fc-run-btn",
                               color="primary", className="mt-2"),
                    width="auto",
                ),
                dbc.Col(
                    dbc.Spinner(html.Div(id="fc-status"), color="primary"),
                    width="auto", className="mt-2",
                ),
            ]),

            dcc.Graph(id="forecast-chart", style={"height": "450px"}),

            dbc.Row([
                dbc.Col(dcc.Graph(id="forecast-components", style={"height": "350px"})),
                dbc.Col([
                    html.H6("📊 Business Impact Summary",
                            style={"color": TEXT_LIGHT, "marginTop": "20px"}),
                    html.Div(id="forecast-summary-table"),
                ]),
            ]),
        ]),

    ], id="main-tabs", active_tab="tab-geo"),

], fluid=True, style={"backgroundColor": BG_DARK, "minHeight": "100vh", "padding": "0 20px"})


# ── Callbacks ────────────────────────────────────────────────────────────────

# KPI strip
@app.callback(Output("kpi-row", "children"), Input("main-tabs", "active_tab"))
def update_kpis(_):
    snap = prepare_geospatial(raw_df)
    total_cases  = f"{snap['total_cases'].sum() / 1e6:.1f}M"
    total_deaths = f"{snap['total_deaths'].sum() / 1e6:.2f}M"
    cfr          = f"{(snap['total_deaths'].sum() / snap['total_cases'].sum() * 100):.2f}%"
    countries    = str(snap["location"].nunique())

    cards = [
        stat_card("Total Cases",         total_cases,  "fa-virus",           BRAND_BLUE),
        stat_card("Total Deaths",         total_deaths, "fa-heart-broken",    BRAND_RED),
        stat_card("Global CFR",           cfr,          "fa-percent",         BRAND_ORANGE),
        stat_card("Countries Tracked",    countries,    "fa-globe",           BRAND_GREEN),
    ]
    return [dbc.Col(c, xs=6, md=3) for c in cards]


# Choropleth
@app.callback(
    Output("choropleth-map",    "figure"),
    Output("top-countries-bar", "figure"),
    Output("cfr-scatter",       "figure"),
    Input("geo-metric", "value"),
    Input("geo-date",   "date"),
)
def update_geo(metric, as_of_date):
    geo = prepare_geospatial(raw_df, as_of_date=as_of_date)

    label_map = {
        "total_cases":       "Total Cases",
        "total_deaths":      "Total Deaths",
        "case_fatality_rate":"Case Fatality Rate (%)",
        "icu_per_million":   "ICU Patients per Million",
        "hosp_per_million":  "Hosp. Patients per Million",
    }
    label = label_map.get(metric, metric)

    # ── Choropleth
    choropleth = px.choropleth(
        geo, locations="iso_code", color=metric,
        hover_name="location",
        hover_data={"total_cases": ":,.0f", "total_deaths": ":,.0f",
                    "case_fatality_rate": ":.2f"},
        color_continuous_scale="Reds",
        labels={metric: label},
        title=f"Global {label} — as of {as_of_date}",
    )
    choropleth.update_layout(**CHART_LAYOUT, geo=dict(bgcolor=CARD_BG, showframe=False))

    # ── Top 15 bar
    top15 = geo.nlargest(15, metric)
    bar = px.bar(
        top15, x=metric, y="location", orientation="h",
        color=metric, color_continuous_scale="Blues",
        title=f"Top 15 Countries — {label}",
        labels={metric: label, "location": ""},
    )
    bar.update_layout(**CHART_LAYOUT)

    # ── CFR vs Cases scatter
    scatter_df = geo.dropna(subset=["case_fatality_rate", "total_cases", "hosp_per_million"])
    scatter = px.scatter(
        scatter_df,
        x="total_cases", y="case_fatality_rate",
        size="population", color="continent",
        hover_name="location",
        log_x=True,
        title="Case Fatality Rate vs Total Cases",
        labels={"total_cases": "Total Cases (log)", "case_fatality_rate": "CFR (%)"},
    )
    scatter.update_layout(**CHART_LAYOUT)

    return choropleth, bar, scatter


# Resource utilization
@app.callback(
    Output("icu-trend",       "figure"),
    Output("hosp-trend",      "figure"),
    Output("bed-occupancy",   "figure"),
    Output("resource-heatmap","figure"),
    Input("res-countries",    "value"),
    Input("res-date-range",   "start_date"),
    Input("res-date-range",   "end_date"),
)
def update_resource(countries, start_date, end_date):
    if not countries:
        empty = go.Figure().update_layout(**CHART_LAYOUT)
        return empty, empty, empty, empty

    res = prepare_resource_utilization(raw_df, countries, start_date, end_date)

    colors = [BRAND_BLUE, BRAND_RED, BRAND_GREEN, BRAND_ORANGE,
              BRAND_PURPLE, "#e9c46a", "#f4a261"]

    def line_chart(col_7d, title, ylab):
        fig = go.Figure()
        for i, country in enumerate(countries):
            sub = res[res["location"] == country]
            if col_7d in sub.columns:
                fig.add_trace(go.Scatter(
                    x=sub["date"], y=sub[col_7d],
                    name=country, mode="lines",
                    line=dict(color=colors[i % len(colors)], width=2),
                ))
        fig.update_layout(**CHART_LAYOUT, title=title,
                          yaxis_title=ylab, xaxis_title="")
        return fig

    icu_fig  = line_chart("icu_patients_per_million_7day_avg",
                          "ICU Patients per Million (7-day avg)", "Per Million")
    hosp_fig = line_chart("hosp_patients_per_million_7day_avg",
                          "Hospitalised Patients per Million (7-day avg)", "Per Million")

    # Bed occupancy
    occ_fig = go.Figure()
    for i, country in enumerate(countries):
        sub = res[res["location"] == country]
        if "bed_occupancy_pct" in sub.columns:
            occ_fig.add_trace(go.Scatter(
                x=sub["date"], y=sub["bed_occupancy_pct"],
                name=country, mode="lines", fill="tozeroy",
                line=dict(color=colors[i % len(colors)], width=1.5),
                fillcolor=colors[i % len(colors)].replace(")", ", 0.15)").replace("rgb", "rgba")
                            if colors[i % len(colors)].startswith("rgb") else colors[i % len(colors)] + "26",
            ))
    occ_fig.add_hline(y=80, line_dash="dash", line_color=BRAND_RED,
                      annotation_text="⚠ 80% capacity alert")
    occ_fig.update_layout(**CHART_LAYOUT, title="Estimated Hospital Bed Occupancy (%)",
                          yaxis_title="%", xaxis_title="")

    # Monthly heatmap of ICU patients for first selected country
    heatmap_country = countries[0]
    sub_hm = res[res["location"] == heatmap_country].copy()
    sub_hm["month"] = sub_hm["date"].dt.to_period("M").astype(str)
    if "icu_patients_per_million" in sub_hm.columns:
        monthly = sub_hm.groupby("month")["icu_patients_per_million"].mean().reset_index()
        monthly["year"]  = monthly["month"].str[:4]
        monthly["month_short"] = pd.to_datetime(monthly["month"]).dt.strftime("%b")
        pivot = monthly.pivot_table(index="year", columns="month_short",
                                    values="icu_patients_per_million")
        hm = px.imshow(
            pivot, color_continuous_scale="YlOrRd",
            title=f"Monthly Avg ICU Patients/Million — {heatmap_country}",
            aspect="auto",
        )
        hm.update_layout(**CHART_LAYOUT)
    else:
        hm = go.Figure().update_layout(**CHART_LAYOUT,
                                       title="ICU data not available for selected country")

    return icu_fig, hosp_fig, occ_fig, hm


# Forecasting
@app.callback(
    Output("forecast-chart",      "figure"),
    Output("forecast-components", "figure"),
    Output("forecast-summary-table", "children"),
    Output("fc-status",           "children"),
    Input("fc-run-btn",  "n_clicks"),
    State("fc-country",  "value"),
    State("fc-target",   "value"),
    State("fc-horizon",  "value"),
    prevent_initial_call=True,
)
def run_forecast(n_clicks, country, target_col, horizon):
    if not n_clicks:
        empty = go.Figure().update_layout(**CHART_LAYOUT)
        return empty, empty, "", ""

    # Prepare data
    df_p = prepare_forecasting(raw_df, country=country,
                               target_col=target_col, start_date="2020-03-01")

    if len(df_p) < 60:
        msg = f"⚠ Not enough data for {country} ({target_col}). Try a different target."
        empty = go.Figure().update_layout(**CHART_LAYOUT)
        return empty, empty, msg, msg

    # Run forecast
    results  = run_forecast_pipeline(df_p, forecast_horizon_days=horizon, run_eval=False)
    forecast = results["forecast"]
    future   = results["future"]
    surge    = results["surge"]

    label_map = {
        "new_cases_smoothed":  "Daily New Cases (7-day avg)",
        "new_deaths_smoothed": "Daily New Deaths (7-day avg)",
        "icu_patients":        "ICU Patients",
        "hosp_patients":       "Hospitalised Patients",
    }
    label = label_map.get(target_col, target_col)

    # ── Main forecast chart
    fig = go.Figure()

    # Historical actuals
    fig.add_trace(go.Scatter(
        x=df_p["ds"], y=df_p["y"],
        name="Actual", mode="lines",
        line=dict(color=BRAND_BLUE, width=1.5),
    ))

    # Forecast line
    fig.add_trace(go.Scatter(
        x=future["ds"], y=future["yhat"],
        name=f"{horizon}-day Forecast", mode="lines",
        line=dict(color=BRAND_ORANGE, width=2.5, dash="dot"),
    ))

    # Confidence interval
    fig.add_trace(go.Scatter(
        x=pd.concat([future["ds"], future["ds"][::-1]]),
        y=pd.concat([future["yhat_upper"], future["yhat_lower"][::-1]]),
        fill="toself",
        fillcolor=BRAND_ORANGE + "33",
        line=dict(color="rgba(0,0,0,0)"),
        name="95% Confidence Interval",
        showlegend=True,
    ))

    # Surge alert shading
    surge_days = surge[surge["is_surge"] & (surge["ds"] > df_p["ds"].max())]
    if not surge_days.empty:
        fig.add_vrect(
            x0=surge_days["ds"].min(), x1=surge_days["ds"].max(),
            fillcolor=BRAND_RED, opacity=0.15,
            annotation_text="⚠ Surge Alert", annotation_position="top left",
            line_width=0,
        )

    fig.update_layout(
        **CHART_LAYOUT,
        title=f"Prophet Forecast — {label} in {country} (+{horizon} days)",
        xaxis_title="", yaxis_title=label,
    )

    # ── Trend & seasonality decomposition
    comp_cols = [c for c in ["trend", "weekly", "yearly"] if c in forecast.columns]
    comp_fig  = make_subplots(rows=len(comp_cols), cols=1,
                               subplot_titles=[c.capitalize() for c in comp_cols])
    comp_colors = [BRAND_BLUE, BRAND_GREEN, BRAND_PURPLE]
    for i, col in enumerate(comp_cols, 1):
        comp_fig.add_trace(
            go.Scatter(x=forecast["ds"], y=forecast[col],
                       line=dict(color=comp_colors[i - 1], width=2), name=col),
            row=i, col=1,
        )
    comp_fig.update_layout(**CHART_LAYOUT, title="Forecast Decomposition",
                           showlegend=False, height=350)
    for i in range(1, len(comp_cols) + 1):
        comp_fig.update_xaxes(gridcolor=GRID_COLOR, row=i, col=1)
        comp_fig.update_yaxes(gridcolor=GRID_COLOR, row=i, col=1)

    # ── Business summary table
    peak_date = future.loc[future["yhat"].idxmax(), "ds"].strftime("%Y-%m-%d")
    peak_val  = f"{future['yhat'].max():,.0f}"
    end_val   = f"{future.iloc[-1]['yhat']:,.0f}"
    trend_dir = "📈 Rising" if future.iloc[-1]["yhat"] > future.iloc[0]["yhat"] else "📉 Falling"
    surge_ct  = len(surge_days)

    table = dbc.Table([
        html.Thead(html.Tr([html.Th("Metric"), html.Th("Value")])),
        html.Tbody([
            html.Tr([html.Td("Forecast Target"), html.Td(label)]),
            html.Tr([html.Td("Country"),         html.Td(country)]),
            html.Tr([html.Td("Horizon"),          html.Td(f"{horizon} days")]),
            html.Tr([html.Td("Peak Predicted"),   html.Td(f"{peak_val} on {peak_date}")]),
            html.Tr([html.Td("End-of-Horizon"),   html.Td(end_val)]),
            html.Tr([html.Td("Trend Direction"),  html.Td(trend_dir)]),
            html.Tr([html.Td("Surge Alert Days"), html.Td(
                html.Span(f"{surge_ct} days",
                          style={"color": BRAND_RED if surge_ct > 0 else BRAND_GREEN})
            )]),
        ]),
    ], bordered=True, hover=True, responsive=True, size="sm",
       style={"color": TEXT_LIGHT, "backgroundColor": CARD_BG})

    status = f"✅ Forecast complete for {country}"
    return fig, comp_fig, table, status


# ── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8050)
